var array=Array();

function addFeedback(){
 //Fill the required logic   
 var string=document.getElementById("feedback").value;
 array.push(string);
 document.getElementById("feedback").value=" ";
 document.getElementById("result").innerHTML="<h2>feedback Details</h2> <br><h3>successfully Added Feedback Details</h3>";
}

function displayFeedback(){
    //Fill the required logic
    document.getElementById("result").innerHTML="";
    document.getElementById("result").innerHTML+="<h2>"+"Feedback Details "+"</h2>";
    for(var i=0;i<array.length;i++){
        document.getElementById("result").innerHTML+="Feedback "+(i+1)+ "<br> "+array[i]+"<br>";
    }
    array[i];
}